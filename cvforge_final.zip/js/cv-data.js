// ═══════════════════════════════════════════════════════════
//  CV FORGE — CV DATA MODULE
//  The CV data model + all form rendering
//  To add a new section: add data here + add renderXxx() + call it in App.init()
// ═══════════════════════════════════════════════════════════

// ── CV Data State ────────────────────────────────────────
const CVData = {
  name: '', phone: '', email: '', linkedin: '', location: '',
  summary: '', skills: '',
  experience:  [],
  education:   [],
  cert:        [],
  languages:   [],
  showCustom:  false,
  customTitle: 'Projects',
  customItems: [],
  template:    't1',
};

// ── Helpers ──────────────────────────────────────────────
function esc(s) {
  if (!s) return '';
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
          .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

function toBullets(text) {
  if (!text) return '';
  return text.split(/\n/).map(l => l.trim()).filter(Boolean)
             .map(l => `<li>${esc(l)}</li>`).join('');
}

function bindField(elId, key) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.value = CVData[key] || '';
  el.addEventListener('input', e => { CVData[key] = e.target.value; CV.render(); });
}

// ── Dynamic Item Builders ────────────────────────────────
function renderExp() {
  document.getElementById('exp-list').innerHTML = CVData.experience.map((j, i) => `
    <div class="dyn">
      <button class="btn-rm" onclick="CVData.experience.splice(${i},1);renderExp();CV.render()">✕</button>
      <div class="ff"><label class="field-label">Job Title</label>
        <input class="input-field" value="${esc(j.title)}" placeholder="e.g. Account Manager"
          oninput="CVData.experience[${i}].title=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Company</label>
        <input class="input-field" value="${esc(j.company)}" placeholder="Company name"
          oninput="CVData.experience[${i}].company=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Dates</label>
        <input class="input-field" value="${esc(j.dates)}" placeholder="2022–Present"
          oninput="CVData.experience[${i}].dates=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Bullets (one per line)</label>
        <textarea class="input-field"
          oninput="CVData.experience[${i}].desc=this.value;CV.render()">${esc(j.desc)}</textarea></div>
    </div>`).join('');
}

function renderEdu() {
  document.getElementById('edu-list').innerHTML = CVData.education.map((e, i) => `
    <div class="dyn">
      <button class="btn-rm" onclick="CVData.education.splice(${i},1);renderEdu();CV.render()">✕</button>
      <div class="ff"><label class="field-label">Degree</label>
        <input class="input-field" value="${esc(e.degree)}" placeholder="e.g. Bachelor of Pharmacy"
          oninput="CVData.education[${i}].degree=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Institution</label>
        <input class="input-field" value="${esc(e.institution)}"
          oninput="CVData.education[${i}].institution=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Year</label>
        <input class="input-field" value="${esc(e.year)}" placeholder="2022"
          oninput="CVData.education[${i}].year=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Location</label>
        <input class="input-field" value="${esc(e.location)}" placeholder="Cairo, Egypt"
          oninput="CVData.education[${i}].location=this.value;CV.render()"></div>
    </div>`).join('');
}

function renderCert() {
  document.getElementById('cert-list').innerHTML = CVData.cert.map((c, i) => `
    <div class="dyn">
      <button class="btn-rm" onclick="CVData.cert.splice(${i},1);renderCert();CV.render()">✕</button>
      <div class="ff"><label class="field-label">Certification Name</label>
        <input class="input-field" value="${esc(c.name)}"
          oninput="CVData.cert[${i}].name=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Issuer</label>
        <input class="input-field" value="${esc(c.issuer)}" placeholder="e.g. HubSpot Academy"
          oninput="CVData.cert[${i}].issuer=this.value;CV.render()"></div>
    </div>`).join('');
}

function renderLang() {
  document.getElementById('lang-list').innerHTML = (CVData.languages || []).map((l, i) => `
    <div class="dyn">
      <button class="btn-rm" onclick="CVData.languages.splice(${i},1);renderLang();CV.render()">✕</button>
      <div class="ff"><label class="field-label">Language</label>
        <input class="input-field" value="${esc(l.name)}"
          oninput="CVData.languages[${i}].name=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Proficiency</label>
        <input class="input-field" value="${esc(l.proficiency)}" placeholder="e.g. Native, C1, Fluent"
          oninput="CVData.languages[${i}].proficiency=this.value;CV.render()"></div>
    </div>`).join('');
}

function renderCustom() {
  document.getElementById('custom-list').innerHTML = (CVData.customItems || []).map((it, i) => `
    <div class="dyn">
      <button class="btn-rm" onclick="CVData.customItems.splice(${i},1);renderCustom();CV.render()">✕</button>
      <div class="ff"><label class="field-label">Title</label>
        <input class="input-field" value="${esc(it.title)}"
          oninput="CVData.customItems[${i}].title=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Subtitle</label>
        <input class="input-field" value="${esc(it.subtitle)}"
          oninput="CVData.customItems[${i}].subtitle=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Dates</label>
        <input class="input-field" value="${esc(it.dates)}"
          oninput="CVData.customItems[${i}].dates=this.value;CV.render()"></div>
      <div class="ff"><label class="field-label">Description (one per line)</label>
        <textarea class="input-field"
          oninput="CVData.customItems[${i}].desc=this.value;CV.render()">${esc(it.desc)}</textarea></div>
    </div>`).join('');
}

// ── Add item shortcuts ────────────────────────────────────
function addExp()    { CVData.experience.push({title:'',company:'',dates:'',desc:''});    renderExp();    CV.render(); }
function addEdu()    { CVData.education.push({degree:'',institution:'',year:'',location:''}); renderEdu(); CV.render(); }
function addCert()   { CVData.cert.push({name:'',issuer:''});                              renderCert();   CV.render(); }
function addLang()   { CVData.languages.push({name:'',proficiency:''});                   renderLang();   CV.render(); }
function addCustom() { CVData.customItems.push({title:'',subtitle:'',dates:'',desc:''}); renderCustom(); CV.render(); }

function toggleCustom(on) {
  CVData.showCustom = on;
  document.getElementById('custom-body').style.display = on ? 'block' : 'none';
  CV.render();
}
