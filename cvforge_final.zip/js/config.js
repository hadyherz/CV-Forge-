// ═══════════════════════════════════════════════════════════
//  CV FORGE — CONFIG MODULE
//  This is the ONLY file you need to edit for most changes.
//  Change price, brand, templates, prompts — all here.
// ═══════════════════════════════════════════════════════════

const CVFORGE_CONFIG = {

  // ── BRAND ──────────────────────────────────────────────
  brand: {
    name:    'CV Forge',
    tagline: 'ATS Optimized Resumes',
    sub:     'Build a professional CV that beats ATS filters',
  },

  // ── PRICING ────────────────────────────────────────────
  // Change the display text here.
  // Change actual charge in Netlify env → PRICE_CENTS
  price: {
    display: '$1.99',
    note:    'One-time · Lifetime access · No subscription',
  },

  // ── FEATURES LIST on paywall ───────────────────────────
  // Add or remove lines freely
  features: [
    '5 ATS-optimized professional templates',
    'Smart writing prompts for every section',
    'Live preview as you type',
    'Export to PDF & Image (unlimited)',
    'Your account saves your CV forever',
  ],

  // ── ADMIN ACCOUNT ──────────────────────────────────────
  // This account bypasses payment — never changes
  // Keep these private — do not share
  admin: {
    email:    'cvforge.admin@proton.me',   // ← change to your real email
    password: 'Cv@F0rge#2025!Admin',       // ← change to something only you know
    bypass_key: 'ADMIN-CVFORGE-2025',      // ← stored in localStorage to skip paywall
  },

  // ── TEMPLATES ──────────────────────────────────────────
  // id must match CSS class .t1 .t2 etc.
  templates: [
    { id: 't1', name: 'Classic',      preview: 'Arial · Clean lines' },
    { id: 't2', name: 'Executive',    preview: 'Georgia · Centered' },
    { id: 't3', name: 'Modern Teal',  preview: 'Calibri · Color accents' },
    { id: 't4', name: 'Bold Corp',    preview: 'Helvetica · Heavy titles' },
    { id: 't5', name: 'Elegant',      preview: 'Serif · Classic style' },
  ],

  // ── AI WRITING PROMPTS ─────────────────────────────────
  // Edit the prompt text shown under each section
  prompts: {
    summary: `"Write a 3-sentence professional summary for a CV. I work as [your job title] with [X] years of experience in [your industry/field]. My key strengths are [strength 1], [strength 2], and [strength 3]. Make it ATS-friendly, use strong action words, and do not use first person."`,

    skills: `"List 10 professional skills for a CV for someone working as [your job title] in [your industry]. Format as a comma-separated list only. Focus on skills that ATS systems look for. Include both hard and soft skills."`,

    experience: `"Write 5 bullet points for a CV work experience entry. My job title was [title] at [company]. My main responsibilities included [describe what you did]. Make each bullet start with a strong action verb, include measurable results where possible, keep each under 15 words. ATS-optimized."`,

    education: `"Write a one-line academic achievement note for a CV. My degree is [degree name] from [university], graduated [year]. Mention any honors, GPA if strong, or relevant coursework."`,

    certifications: `"Suggest 5 relevant professional certifications I should list on my CV. I work as [your job title] in [your industry]. List only certification name and issuing organization."`,

    languages: `"How should I describe my language proficiency on a professional CV? I speak [language] at [your level]. Use professional CV language like Native, Fluent, Professional Working Proficiency, or CEFR levels."`,

    custom: `"Write 3-4 bullet points for a [section name, e.g. Volunteer Work / Projects] entry on my CV. The project/role was [describe it briefly]. Focus on impact, skills used, and results achieved."`,
  },

  // ── APPWRITE ───────────────────────────────────────────
  // Get these from cloud.appwrite.io after creating your project
  appwrite: {
    endpoint:   'https://cloud.appwrite.io/v1',
    projectId:  'YOUR_PROJECT_ID',   // ← paste your Appwrite Project ID here
  },

};
