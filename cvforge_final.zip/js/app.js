// ═══════════════════════════════════════════════════════════
//  CV FORGE — APP MODULE
//  Main controller — boots the app, wires everything together
// ═══════════════════════════════════════════════════════════

const App = {

  currentUser: null,

  // ── BOOT ─────────────────────────────────────────────────
  async boot() {
    // Check if returning from Paymob payment
    const paid = await Payment.verifyRedirect();

    // Check existing session
    try {
      const acc = await Auth.getSession();
      if (acc?.$id) {
        App.currentUser = acc;
        const hasPaid = paid || Auth.isPaid() || Auth.isAdminSession();
        Screen.show(hasPaid ? 'app' : 'paywall');
        if (hasPaid) App.init();
        return;
      }
    } catch (e) { /* no session */ }

    // No session → show auth
    Screen.show('auth');
  },

  // ── INIT APP ─────────────────────────────────────────────
  init() {
    // Build dynamic UI from config
    buildPaywallFeatures();
    buildTemplateGrid();

    // Bind all simple text fields
    bindField('f-name',     'name');
    bindField('f-phone',    'phone');
    bindField('f-email',    'email');
    bindField('f-linkedin', 'linkedin');
    bindField('f-location', 'location');
    bindField('f-summary',  'summary');
    bindField('f-skills',   'skills');
    bindField('f-ctitle',   'customTitle');

    // Pre-fill name from account if empty
    if (App.currentUser?.name && !CVData.name) {
      CVData.name = App.currentUser.name;
      const el = document.getElementById('f-name');
      if (el) el.value = CVData.name;
    }

    // Build prompt helpers
    buildPromptHelper('prompt-summary-wrap',  'summary');
    buildPromptHelper('prompt-skills-wrap',   'skills');
    buildPromptHelper('prompt-exp-wrap',      'experience');
    buildPromptHelper('prompt-edu-wrap',      'education');
    buildPromptHelper('prompt-cert-wrap',     'certifications');
    buildPromptHelper('prompt-lang-wrap',     'languages');
    buildPromptHelper('prompt-custom-wrap',   'custom');

    // Custom section toggle
    const togEl = document.getElementById('tog-custom');
    if (togEl) {
      togEl.checked = CVData.showCustom;
      document.getElementById('custom-body').style.display = CVData.showCustom ? 'block' : 'none';
    }

    // Render all dynamic form lists
    renderExp();
    renderEdu();
    renderCert();
    renderLang();
    renderCustom();

    // Initial CV render
    CV.render();

    // Show admin badge if admin
    if (Auth.isAdminSession()) {
      const badge = document.getElementById('admin-badge');
      if (badge) badge.style.display = 'inline-block';
    }
  },

};

// ── Start everything when DOM is ready ───────────────────
document.addEventListener('DOMContentLoaded', () => App.boot());
