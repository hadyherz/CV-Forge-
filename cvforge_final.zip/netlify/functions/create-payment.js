// ═══════════════════════════════════════════════════════════
//  CV FORGE — Netlify Function: create-payment
//  Handles Paymob payment creation
//  Do not edit unless changing payment provider
// ═══════════════════════════════════════════════════════════

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  const API_KEY        = process.env.PAYMOB_API_KEY;
  const INTEGRATION_ID = process.env.PAYMOB_INTEGRATION_ID;
  const PRICE_CENTS    = parseInt(process.env.PRICE_CENTS || '199');
  const CURRENCY       = process.env.CURRENCY || 'USD';

  if (!API_KEY || !INTEGRATION_ID) {
    return { statusCode: 500, headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Payment not configured. Check Netlify environment variables.' }) };
  }

  try {
    // Step 1: Auth
    const authRes = await fetch('https://accept.paymob.com/api/auth/tokens', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: API_KEY })
    });
    const { token } = await authRes.json();
    if (!token) throw new Error('Paymob auth failed — check your API key');

    // Step 2: Order
    const orderRes = await fetch('https://accept.paymob.com/api/ecommerce/orders', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auth_token: token, delivery_needed: false,
        amount_cents: PRICE_CENTS, currency: CURRENCY,
        items: [{ name: 'CV Forge — Lifetime Access', amount_cents: PRICE_CENTS, description: 'ATS CV Builder', quantity: 1 }]
      })
    });
    const { id: orderId } = await orderRes.json();
    if (!orderId) throw new Error('Order creation failed');

    // Step 3: Payment key
    const keyRes = await fetch('https://accept.paymob.com/api/acceptance/payment_keys', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auth_token: token, amount_cents: PRICE_CENTS, expiration: 3600,
        order_id: orderId, currency: CURRENCY,
        integration_id: parseInt(INTEGRATION_ID),
        billing_data: {
          first_name: 'CV', last_name: 'Forge', email: 'user@cvforge.com',
          phone_number: 'NA', apartment: 'NA', floor: 'NA', street: 'NA',
          building: 'NA', shipping_method: 'NA', postal_code: 'NA',
          city: 'NA', country: 'NA', state: 'NA'
        }
      })
    });
    const { token: payKey } = await keyRes.json();
    if (!payKey) throw new Error('Payment key failed');

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        payment_url: `https://accept.paymob.com/api/acceptance/iframes/${INTEGRATION_ID}?payment_token=${payKey}`
      })
    };
  } catch (err) {
    console.error('[create-payment]', err.message);
    return { statusCode: 500, headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: err.message }) };
  }
};
