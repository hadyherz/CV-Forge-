// ═══════════════════════════════════════════════════════════
//  CV FORGE — Netlify Function: verify-payment
//  Verifies Paymob HMAC signature after redirect
// ═══════════════════════════════════════════════════════════
const crypto = require('crypto');

exports.handler = async (event) => {
  const p    = event.queryStringParameters || {};
  const HMAC = process.env.PAYMOB_HMAC;

  if (!HMAC) {
    return { statusCode: 500, headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: false, reason: 'HMAC not configured' }) };
  }

  // Fields Paymob uses for HMAC — do not reorder
  const fields = [
    'amount_cents','created_at','currency','error_occured',
    'has_parent_transaction','id','integration_id','is_3d_secure',
    'is_auth','is_capture','is_refunded','is_standalone_payment',
    'is_voided','order','owner','pending','source_data_pan',
    'source_data_sub_type','source_data_type','success'
  ];

  const str      = fields.map(f => p[f] ?? '').join('');
  const computed = crypto.createHmac('sha512', HMAC).update(str).digest('hex');
  const valid    = computed === p.hmac && p.success === 'true';

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ success: valid })
  };
};
