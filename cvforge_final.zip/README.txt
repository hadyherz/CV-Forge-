# CV FORGE — Complete Developer & Setup Guide
# ═══════════════════════════════════════════════════════════
# Read this fully before deploying. Everything you need is here.
# ═══════════════════════════════════════════════════════════


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 PROJECT STRUCTURE — What each file does
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

cvforge-final/
│
├── index.html                  ← App shell (HTML only, no logic)
│                                 Edit this to change page structure
│
├── netlify.toml                ← Netlify config (routes + security headers)
│                                 Edit this if you add new backend routes
│
├── css/
│   └── styles.css              ← ALL styling
│                                 Edit colors in :root at the top
│                                 Edit layout, fonts, spacing here
│
├── js/
│   ├── config.js               ★ THE MAIN FILE TO EDIT
│   │                             Change: price, brand, features list,
│   │                             admin credentials, templates, prompts
│   │
│   ├── auth.js                 ← Sign in / Sign up / Logout logic
│   │                             Uses Appwrite. Edit only if changing auth provider.
│   │
│   ├── payment.js              ← Payment start + verification
│   │                             Edit only if changing payment provider.
│   │
│   ├── cv-data.js              ← CV data model + dynamic form builders
│   │                             Edit to add new CV sections or fields
│   │
│   ├── cv-render.js            ← Builds CV HTML from data
│   │                             Edit to change CV layout or add sections
│   │
│   ├── ui.js                   ← Screen switching, tabs, export, copy prompts
│   │                             Edit for UI behavior changes
│   │
│   └── app.js                  ← App boot + controller
│                                 Edit load order or add new init steps
│
└── netlify/
    └── functions/
        ├── create-payment.js   ← Paymob payment creation (server-side)
        └── verify-payment.js   ← Paymob HMAC verification (server-side)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 QUICK REFERENCE — Most common changes
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  CHANGE PRICE DISPLAY      →  js/config.js  →  price.display
  CHANGE ACTUAL CHARGE      →  Netlify env   →  PRICE_CENTS  (USD cents, e.g. 199 = $1.99)
  CHANGE FEATURES LIST      →  js/config.js  →  features[]
  CHANGE WRITING PROMPTS    →  js/config.js  →  prompts{}
  CHANGE COLORS             →  css/styles.css → :root variables
  CHANGE FONTS              →  index.html (Google Fonts link) + css/styles.css → --fh / --fb
  ADD A NEW CV SECTION      →  js/cv-data.js + js/cv-render.js + index.html
  ADD A NEW TEMPLATE        →  css/styles.css (add .t6) + js/config.js templates[]
  CHANGE ADMIN CREDENTIALS  →  js/config.js  →  admin{}


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 1 — SET UP APPWRITE (Free database + auth)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Appwrite stores user accounts and handles sign in / sign up.

1. Go to: https://cloud.appwrite.io
2. Create a free account (use Google or GitHub)
3. Click "Create Project" → name it "cvforge" → click Create
4. You will see your Project ID in the top bar (looks like: 64f3c9a2b...)
   → Copy this Project ID

5. Enable Email/Password auth:
   → Left menu → Auth → Settings
   → Make sure "Email/Password" is toggled ON

6. Add your Netlify domain (so Appwrite allows requests from it):
   → Left menu → Settings → Platforms
   → Click "Add Platform" → "Web App"
   → Name: CV Forge
   → Hostname: your-site.netlify.app  ← paste your Netlify domain here
   → Also add: localhost (for local testing)

7. Paste your Project ID into js/config.js:
   → Find:  projectId: 'YOUR_PROJECT_ID'
   → Replace with your actual ID

That's it for Appwrite — no database tables needed, it handles users automatically.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 2 — SET UP PAYMOB (Payment processing)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Go to: https://accept.paymob.com/portal2/en/signup
2. Sign up as individual (use your National ID)
3. Wait for approval email (1–3 business days)

Once approved, collect your 3 keys:

   KEY 1 — API Key
   → Settings → Account Info → copy "API Key"

   KEY 2 — Integration ID
   → Developers → Payment Integrations
   → Find "Card Payments" integration → copy the ID number
   → If none exists: click "+ Add Integration" → Online Card Payment

   KEY 3 — HMAC Secret
   → Settings → Account Info → click "View" next to HMAC → copy

4. Set your callback URL in Paymob:
   → Developers → Payment Integrations → click your integration
   → Transaction Response URL: https://YOUR-SITE.netlify.app/payment-callback
   → Server Callback URL:      https://YOUR-SITE.netlify.app/verify-payment

Test cards (use in Paymob TEST mode):
   Successful: 4987 6542 3456 5888  |  Expiry: 05/21  |  CVV: 100
   Failed:     4000 0000 0000 0002


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 3 — DEPLOY TO NETLIFY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Go to https://netlify.com → log in
2. Click "Add new site" → "Deploy manually"
3. Unzip cvforge-final.zip on your computer
4. Drag the CONTENTS of the folder (not the folder itself) into Netlify
   → You should see: index.html, netlify.toml, css/, js/, netlify/
5. Netlify will give you a URL like: https://random-name.netlify.app
   → You can rename: Site Settings → General → Site name

IMPORTANT: Drag the FILES inside the folder, not the folder itself.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 4 — ADD ENVIRONMENT VARIABLES TO NETLIFY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

In Netlify → Site Configuration → Environment Variables → Add variable:

   Variable Name           Value
   ─────────────────────────────────────────────────────────────────
   PAYMOB_API_KEY          ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFhWQ0o5...
   PAYMOB_INTEGRATION_ID   5576664
   PAYMOB_HMAC             C86974F48EACDDCF699C0759F9FC0886
   BASE_URL                https://your-site.netlify.app
   PRICE_CENTS             199     ← $1.99 USD (change to e.g. 499 for $4.99)
   CURRENCY                USD
   ─────────────────────────────────────────────────────────────────

After adding: Deploys → Trigger deploy → Deploy site


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 ADMIN ACCESS — Your special account
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The admin account bypasses payment completely.
It is defined in js/config.js under the "admin" section.

Default credentials (CHANGE THESE before deploying):
   Email:    cvforge.admin@proton.me
   Password: Cv@F0rge#2025!Admin

How it works:
→ You sign in with the admin email + password
→ The app recognizes it without calling Appwrite
→ You get full access with an "ADMIN" badge in the top bar
→ No payment required, ever
→ Works even if Appwrite is down

TO CHANGE ADMIN CREDENTIALS:
→ Open js/config.js
→ Find the "admin" section
→ Change email, password, and bypass_key to something only you know
→ Redeploy to Netlify

SECURITY TIPS:
→ Use a strong password (mix of letters, numbers, symbols)
→ Use an email you own but don't share publicly
→ Change the bypass_key to something random (e.g. "MY-SECRET-99XK2")
→ Never share js/config.js with anyone


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 SECURITY — What's protected and how
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. PAYMENT KEYS ARE SERVER-SIDE ONLY
   → Paymob API key, HMAC, and Integration ID live in Netlify
     environment variables — never in the browser-facing code
   → Users cannot see or steal your payment keys

2. PAYMENT VERIFICATION
   → Every payment is verified using Paymob's HMAC cryptographic
     signature before access is granted
   → Faking a payment redirect won't work without the HMAC key

3. SECURITY HEADERS (in netlify.toml)
   → X-Frame-Options: DENY — prevents your site being embedded in iframes
   → X-Content-Type-Options: nosniff — prevents MIME sniffing attacks
   → Content-Security-Policy — restricts which external resources can load
   → Referrer-Policy: no-referrer — hides your URL from third parties

4. NO CODE INJECTION POSSIBLE
   → Users cannot modify the app code — all JS files are served from
     your Netlify deployment which only you control via GitHub/drag-drop
   → CV data exists only in the user's browser session (not stored server-side)

5. APPWRITE AUTH
   → Passwords are hashed by Appwrite — you never see them
   → Sessions are managed securely via Appwrite cookies

6. TO LOCK DOWN FURTHER (optional):
   → Enable 2FA on your Netlify account
   → Enable 2FA on your Appwrite account
   → Enable 2FA on your Paymob account
   → Set up a custom domain with HTTPS (Netlify does this automatically)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 HOW TO UPDATE THE APP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

After making changes to any file:

1. Unzip the project folder on your computer (if not already unzipped)
2. Make your edits
3. Go to Netlify → your site → Deploys
4. Drag the updated folder contents into the deploy box
5. Wait ~30 seconds → your changes are live

You do NOT need to touch Netlify environment variables unless
you're changing prices or API keys.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 PRICE REFERENCE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  PRICE_CENTS    Display
  ─────────────────────
  99             $0.99
  199            $1.99
  299            $2.99
  499            $4.99
  999            $9.99

Set PRICE_CENTS in Netlify environment variables.
Set the display text in js/config.js → price.display


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 TROUBLESHOOTING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

"Page not found" on Netlify
→ Make sure you dragged the FILE CONTENTS, not the folder itself
→ index.html must be at the root, not inside a subfolder

"Could not start payment"
→ Check Netlify: Site → Functions → create-payment → view logs
→ Make sure PAYMOB_API_KEY is set correctly with no spaces
→ Make sure Paymob account is approved and not in pending state

"Sign in not working"
→ Check that your Appwrite Project ID is correct in js/config.js
→ Check that your Netlify domain is added in Appwrite → Settings → Platforms
→ Make sure Email/Password is enabled in Appwrite → Auth → Settings

"Payment verified but still shows paywall"
→ Clear browser localStorage: open browser console → localStorage.clear()
→ Then sign in again and pay

App not updating after redeploy
→ Hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)
→ Or clear browser cache


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 SUPPORT CONTACTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Paymob:   support@paymob.com  |  hotline: 19079
  Appwrite: https://appwrite.io/discord
  Netlify:  https://answers.netlify.com

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 Good luck with CV Forge! 🔨
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
