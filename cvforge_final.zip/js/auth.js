// ═══════════════════════════════════════════════════════════
//  CV FORGE — AUTH MODULE
//  Handles sign in, sign up, logout, session check
//  Uses Appwrite as backend — no changes needed here
// ═══════════════════════════════════════════════════════════

const Auth = (() => {

  // ── Appwrite thin API wrapper ──────────────────────────
  function headers() {
    return {
      'Content-Type': 'application/json',
      'X-Appwrite-Project': CVFORGE_CONFIG.appwrite.projectId,
    };
  }

  async function awCall(method, path, body) {
    try {
      const r = await fetch(CVFORGE_CONFIG.appwrite.endpoint + path, {
        method,
        headers: headers(),
        credentials: 'include',
        body: body ? JSON.stringify(body) : undefined,
      });
      return r.json();
    } catch (e) {
      return { error: e.message };
    }
  }

  // ── Public methods ──────────────────────────────────────
  async function getSession() {
    return awCall('GET', '/account');
  }

  async function signUp(name, email, password) {
    const res = await awCall('POST', '/account', {
      userId: 'unique()', name, email, password,
    });
    if (res.$id) {
      // Auto sign in after signup
      return signIn(email, password);
    }
    return res;
  }

  async function signIn(email, password) {
    return awCall('POST', '/account/sessions/email', { email, password });
  }

  async function signOut() {
    return awCall('DELETE', '/account/sessions/current');
  }

  // ── Admin bypass check ─────────────────────────────────
  function isAdminSession() {
    return localStorage.getItem('cvforge_admin') === CVFORGE_CONFIG.admin.bypass_key;
  }

  function setAdminSession() {
    localStorage.setItem('cvforge_admin', CVFORGE_CONFIG.admin.bypass_key);
    localStorage.setItem('cvforge_paid', 'true');
  }

  function isPaid() {
    return localStorage.getItem('cvforge_paid') === 'true';
  }

  function clearSession() {
    localStorage.removeItem('cvforge_paid');
    localStorage.removeItem('cvforge_admin');
  }

  return { getSession, signUp, signIn, signOut, isAdminSession, setAdminSession, isPaid, clearSession };

})();

// ── UI Auth handlers ────────────────────────────────────
function switchAuthTab(tab) {
  document.querySelectorAll('.auth-tab').forEach((t, i) =>
    t.classList.toggle('active', (i === 0 && tab === 'signin') || (i === 1 && tab === 'signup'))
  );
  document.getElementById('form-signin').classList.toggle('active', tab === 'signin');
  document.getElementById('form-signup').classList.toggle('active', tab === 'signup');
}

function showMsg(id, text, type) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
  el.className = `msg ${type} show`;
}

async function doSignIn() {
  const email = document.getElementById('si-email').value.trim();
  const pass  = document.getElementById('si-pass').value;
  if (!email || !pass) { showMsg('si-msg', 'Please fill in all fields', 'err'); return; }

  UI.setLoading('si-btn', 'Signing in...');

  // Check if admin credentials
  if (email === CVFORGE_CONFIG.admin.email && pass === CVFORGE_CONFIG.admin.password) {
    Auth.setAdminSession();
    UI.setLoading('si-btn', 'Sign In', false);
    App.currentUser = { name: 'Admin', email, isAdmin: true };
    Screen.show('app');
    App.init();
    return;
  }

  const res = await Auth.signIn(email, pass);
  UI.setLoading('si-btn', 'Sign In', false);

  if (res.$id || res.userId) {
    const acc = await Auth.getSession();
    App.currentUser = acc;
    const paid = Auth.isPaid();
    Screen.show(paid ? 'app' : 'paywall');
    if (paid) App.init();
  } else {
    showMsg('si-msg', res.message || 'Invalid email or password', 'err');
  }
}

async function doSignUp() {
  const name  = document.getElementById('su-name').value.trim();
  const email = document.getElementById('su-email').value.trim();
  const pass  = document.getElementById('su-pass').value;
  if (!name || !email || !pass) { showMsg('su-msg', 'Please fill in all fields', 'err'); return; }
  if (pass.length < 8) { showMsg('su-msg', 'Password must be at least 8 characters', 'err'); return; }

  UI.setLoading('su-btn', 'Creating account...');
  const res = await Auth.signUp(name, email, pass);
  UI.setLoading('su-btn', 'Create Account', false);

  if (res.$id || res.userId) {
    const acc = await Auth.getSession();
    App.currentUser = acc;
    showMsg('su-msg', 'Account created!', 'ok');
    setTimeout(() => {
      Screen.show(Auth.isPaid() ? 'app' : 'paywall');
      if (Auth.isPaid()) App.init();
    }, 700);
  } else {
    showMsg('su-msg', res.message || 'Could not create account. Try again.', 'err');
  }
}

async function doLogout() {
  await Auth.signOut();
  Auth.clearSession();
  App.currentUser = null;
  Screen.show('auth');
}
