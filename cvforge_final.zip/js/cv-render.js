// ═══════════════════════════════════════════════════════════
//  CV FORGE — CV RENDER MODULE
//  Builds the CV HTML from CVData and injects into preview
//  To add a new section to the CV output: add a block here
// ═══════════════════════════════════════════════════════════

const CV = (() => {

  function buildHTML() {
    const D = CVData;
    let h = `
      <header>
        <h1>${esc(D.name)}</h1>
        <div class="cv-contact">
          ${[D.phone, D.email, D.linkedin, D.location].filter(Boolean).map(esc).join(' · ')}
        </div>
      </header>`;

    if (D.summary)
      h += `<section><h2>Professional Summary</h2><p>${esc(D.summary)}</p></section>`;

    const skills = D.skills.split(',').map(s => s.trim()).filter(Boolean);
    if (skills.length)
      h += `<section><h2>Core Competencies</h2>
              <ul style="columns:2">${skills.map(s => `<li>${esc(s)}</li>`).join('')}</ul>
            </section>`;

    if (D.experience.length)
      h += `<section><h2>Work Experience</h2>${D.experience.map(j => `
        <div style="margin-bottom:14px">
          <div style="display:flex;justify-content:space-between;align-items:baseline">
            <h3>${esc(j.title)}</h3>
            <span style="font-size:8.5pt;font-weight:500">${esc(j.dates)}</span>
          </div>
          <div class="cv-meta">${esc(j.company)}</div>
          <ul>${toBullets(j.desc)}</ul>
        </div>`).join('')}</section>`;

    if (D.education.length)
      h += `<section><h2>Education</h2>${D.education.map(e => `
        <div style="margin-bottom:9px">
          <div style="display:flex;justify-content:space-between;align-items:baseline">
            <h3>${esc(e.degree)}</h3>
            <span style="font-size:8.5pt;font-weight:500">${esc(e.year)}</span>
          </div>
          <div class="cv-meta">${esc(e.institution)}${e.location ? ', ' + esc(e.location) : ''}</div>
        </div>`).join('')}</section>`;

    if (D.showCustom && D.customItems?.length) {
      const hasContent = D.customItems.some(i => i.title || i.desc);
      if (hasContent)
        h += `<section><h2>${esc(D.customTitle || 'Custom')}</h2>${D.customItems.map(i => `
          <div style="margin-bottom:13px">
            <div style="display:flex;justify-content:space-between;align-items:baseline">
              <h3>${esc(i.title)}</h3>
              <span style="font-size:8.5pt;font-weight:500">${esc(i.dates)}</span>
            </div>
            <div class="cv-meta">${esc(i.subtitle)}</div>
            <ul>${toBullets(i.desc)}</ul>
          </div>`).join('')}</section>`;
    }

    if (D.cert.length)
      h += `<section><h2>Certifications & Awards</h2><ul>
              ${D.cert.map(c => `<li><strong>${esc(c.name)}</strong> — ${esc(c.issuer)}</li>`).join('')}
            </ul></section>`;

    if (D.languages?.length)
      h += `<section><h2>Languages</h2><ul>
              ${D.languages.map(l => `<li><strong>${esc(l.name)}</strong> — ${esc(l.proficiency)}</li>`).join('')}
            </ul></section>`;

    return h;
  }

  function render() {
    const html = buildHTML();
    const tpl  = CVData.template;
    ['cv-doc', 'cv-doc-mobile'].forEach(id => {
      const el = document.getElementById(id);
      if (el) { el.className = 'cv-doc ' + tpl; el.innerHTML = html; }
    });
  }

  function setTemplate(tpl, el) {
    CVData.template = tpl;
    document.querySelectorAll('.tpl-opt').forEach(o => o.classList.remove('selected'));
    if (el) el.classList.add('selected');
    render();
  }

  return { render, setTemplate };

})();
