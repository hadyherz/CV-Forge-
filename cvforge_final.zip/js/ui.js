// ═══════════════════════════════════════════════════════════
//  CV FORGE — UI MODULE
//  Screen switching, loading states, tabs, export, prompts
// ═══════════════════════════════════════════════════════════

// ── Screen Manager ────────────────────────────────────────
const Screen = {
  show(name) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const el = document.getElementById('screen-' + name);
    if (el) el.classList.add('active');
  }
};

// ── UI Helpers ────────────────────────────────────────────
const UI = {
  setLoading(btnId, text, loading = true) {
    const el = document.getElementById(btnId);
    if (!el) return;
    el.innerHTML = loading ? `<span class="spin"></span>${text}` : text;
    el.disabled = loading;
  },
};

// ── Tab Navigation ────────────────────────────────────────
function showTab(name) {
  document.querySelectorAll('.tab-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.mob-tab').forEach(t => t.classList.remove('active'));
  const section = document.getElementById('tab-' + name);
  if (section) section.classList.add('active');
  // Find and highlight the right tab button
  document.querySelectorAll('.mob-tab').forEach(t => {
    if (t.getAttribute('data-tab') === name) t.classList.add('active');
  });
}

// ── Prompt Copy ───────────────────────────────────────────
function copyPrompt(key) {
  const text = CVFORGE_CONFIG.prompts[key] || '';
  navigator.clipboard.writeText(text).then(() => {
    const btn = event.target;
    btn.textContent = '✓ Copied!';
    setTimeout(() => btn.textContent = '📋 Copy Prompt', 2000);
  }).catch(() => {
    // Fallback for older browsers
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    event.target.textContent = '✓ Copied!';
    setTimeout(() => event.target.textContent = '📋 Copy Prompt', 2000);
  });
}

// ── Export ────────────────────────────────────────────────
function doPDF() {
  alert(
    'To save as PDF:\n\n' +
    '1. In the dialog that opens, find "Destination" or "Printer"\n' +
    '2. Select "Save as PDF"\n' +
    '3. Click Save\n\n' +
    'This keeps your CV text readable by ATS systems.'
  );
  window.print();
}

function doImg() {
  const el = document.getElementById('cv-doc');
  if (!el) return;
  html2canvas(el, { scale: 2, useCORS: true }).then(canvas => {
    const a = document.createElement('a');
    a.download = 'cv-forge.png';
    a.href = canvas.toDataURL('image/png');
    a.click();
  });
}

// ── Mobile Preview Modal ──────────────────────────────────
function openPreviewMobile() {
  CV.render();
  document.getElementById('preview-modal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closePreviewMobile() {
  document.getElementById('preview-modal').classList.remove('open');
  document.body.style.overflow = '';
}

// ── Build Paywall Features from Config ───────────────────
function buildPaywallFeatures() {
  const container = document.getElementById('pw-features');
  if (!container) return;
  container.innerHTML = CVFORGE_CONFIG.features
    .map(f => `<div class="pw-feat"><span class="pw-feat-icon">✓</span>${f}</div>`)
    .join('');
}

// ── Build Template Selector from Config ──────────────────
function buildTemplateGrid() {
  const grid = document.getElementById('tpl-grid');
  if (!grid) return;
  grid.innerHTML = CVFORGE_CONFIG.templates.map((t, i) => `
    <div class="tpl-opt ${i === 0 ? 'selected' : ''}"
         onclick="CV.setTemplate('${t.id}', this)">
      ${t.name}
      <div class="tpl-preview">${t.preview}</div>
    </div>`).join('');
}

// ── Build Prompt Helpers from Config ─────────────────────
function buildPromptHelper(containerId, promptKey) {
  const el = document.getElementById(containerId);
  if (!el || !CVFORGE_CONFIG.prompts[promptKey]) return;
  el.innerHTML = `
    <div class="prompt-helper">
      <div class="prompt-helper-label">💡 Writing Prompt — paste into ChatGPT / Gemini</div>
      <div class="prompt-helper-text">${CVFORGE_CONFIG.prompts[promptKey]}</div>
      <button class="prompt-copy-btn" onclick="copyPrompt('${promptKey}')">📋 Copy Prompt</button>
    </div>`;
}
