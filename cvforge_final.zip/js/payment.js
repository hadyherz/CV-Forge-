// ═══════════════════════════════════════════════════════════
//  CV FORGE — PAYMENT MODULE
//  Handles Paymob payment flow and verification
// ═══════════════════════════════════════════════════════════

const Payment = (() => {

  async function start() {
    document.getElementById('pay-overlay').classList.add('show');
    try {
      const res = await fetch('/create-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (data.payment_url) {
        window.location.href = data.payment_url;
      } else {
        throw new Error(data.error || 'No payment URL returned');
      }
    } catch (e) {
      document.getElementById('pay-overlay').classList.remove('show');
      alert('Could not start payment. Please try again.\n\nError: ' + e.message);
    }
  }

  async function verifyRedirect() {
    const params = new URLSearchParams(window.location.search);
    if (params.get('payment') !== 'success') return false;

    try {
      const res = await fetch('/verify-payment?' + params.toString());
      const data = await res.json();
      if (data.success) {
        localStorage.setItem('cvforge_paid', 'true');
        window.history.replaceState({}, '', '/');
        return true;
      }
    } catch (e) {
      console.error('Verification error:', e);
    }
    return false;
  }

  return { start, verifyRedirect };

})();

// ── UI payment handler ───────────────────────────────────
async function startPayment() {
  await Payment.start();
}
